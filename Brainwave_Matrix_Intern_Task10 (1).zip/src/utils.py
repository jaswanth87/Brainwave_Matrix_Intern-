import re

URL_RE = re.compile(r"http\S+")
MENTION_RE = re.compile(r"@\w+")
HASH_RE = re.compile(r"#")
NONALPHA_RE = re.compile(r"[^A-Za-z\s]+")

def clean_text(text: str) -> str:
    if not isinstance(text, str):
        text = str(text)
    text = URL_RE.sub("", text)
    text = MENTION_RE.sub("", text)
    text = HASH_RE.sub("", text)
    text = NONALPHA_RE.sub(" ", text)
    return " ".join(text.lower().split())
