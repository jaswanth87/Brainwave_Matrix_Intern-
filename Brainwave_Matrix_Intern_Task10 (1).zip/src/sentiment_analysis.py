import argparse
import os
import pandas as pd
import matplotlib.pyplot as plt
from wordcloud import WordCloud
from textblob import TextBlob
from utils import clean_text
import matplotlib

def polarity(text: str) -> float:
    return TextBlob(text).sentiment.polarity

def label(p: float) -> str:
    if p > 0.05:
        return "Positive"
    elif p < -0.05:
        return "Negative"
    return "Neutral"

def make_charts(df: pd.DataFrame, charts_dir: str, font_path: str = None):
    os.makedirs(charts_dir, exist_ok=True)

    counts = df["sentiment"].value_counts().reindex(["Positive","Neutral","Negative"]).fillna(0)

    plt.figure()
    counts.plot(kind="bar")
    plt.title("Sentiment Distribution")
    plt.xlabel("Sentiment")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, "sentiment_distribution.png"), dpi=200)
    plt.close()

    plt.figure()
    counts.plot(kind="pie", autopct="%1.1f%%")
    plt.title("Sentiment Breakdown")
    plt.ylabel("")
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, "sentiment_pie.png"), dpi=200)
    plt.close()

    # Wordclouds
    for lbl in ["Positive","Negative"]:
        text_blob = " ".join(df.loc[df["sentiment"] == lbl, "clean_text"].astype(str))
        if text_blob.strip():
            wc = WordCloud(width=1000, height=500, background_color="white", font_path=font_path).generate(text_blob)
            plt.figure()
            plt.imshow(wc, interpolation="bilinear")
            plt.axis("off")
            plt.title(f"{lbl} WordCloud")
            plt.tight_layout()
            plt.savefig(os.path.join(charts_dir, f"wordcloud_{lbl.lower()}.png"), dpi=200)
            plt.close()

def main():
    parser = argparse.ArgumentParser(description="Task 10: Social Media Sentiment Analysis")
    parser.add_argument("--input", required=True, help="Path to CSV file")
    parser.add_argument("--text_col", default="tweet", help="Column name containing text")
    parser.add_argument("--outdir", default="outputs", help="Output directory")
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    charts_dir = os.path.join(args.outdir, "charts")
    os.makedirs(charts_dir, exist_ok=True)

    df = pd.read_csv(args.input)
    if args.text_col not in df.columns:
        raise ValueError(f"Column '{args.text_col}' not found. Columns: {list(df.columns)}")

    df["clean_text"] = df[args.text_col].astype(str).apply(clean_text)
    df["polarity"] = df["clean_text"].apply(polarity)
    df["sentiment"] = df["polarity"].apply(label)

    out_csv = os.path.join(args.outdir, "sentiment_results.csv")
    df.to_csv(out_csv, index=False)

    # Try to fetch a TTF font from matplotlib's data (ensures wordcloud works)
    try:
        font_path = os.path.join(matplotlib.get_data_path(), "fonts", "ttf", "DejaVuSans.ttf")
        if not os.path.exists(font_path):
            font_path = None
    except Exception:
        font_path = None

    make_charts(df, charts_dir, font_path=font_path)
    print(f"Saved CSV to: {out_csv}")
    print(f"Charts in: {charts_dir}")

if __name__ == "__main__":
    main()
