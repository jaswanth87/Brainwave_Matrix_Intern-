WordCloud images could not be generated in this environment.
Run the script locally to produce:
- wordcloud_positive.png
- wordcloud_negative.png
