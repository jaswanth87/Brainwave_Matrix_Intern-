# Task 10 — Social Media Sentiment Analysis (Brainwave Matrix Intern)

## Run locally
```bash
pip install -r requirements.txt
python src/sentiment_analysis.py --input data/sample_tweets.csv --text_col tweet --outdir outputs
```
Outputs will be saved to `outputs/` and `outputs/charts/`.
