# Task 10 Report — Social Media Sentiment Analysis

## Abstract
(Write a 6–8 line summary of the problem, dataset, method, and results.)

## 1. Introduction
- What is sentiment analysis?
- Real-world applications.

## 2. Objective
- State your project goal clearly.

## 3. Dataset Description
- Source, number of rows, fields.

## 4. Methodology
- Preprocessing steps.
- Sentiment scoring (TextBlob).
- Label mapping.

## 5. Results
- Paste charts from `outputs/charts/`:
  - `sentiment_distribution.png`
  - `sentiment_pie.png`
  - `wordcloud_positive.png`
  - `wordcloud_negative.png`
- Key observations.

## 6. Conclusion
- What did you learn?

## 7. Future Work
- Ideas to improve.

## 8. References
- Any links/datasets used.
